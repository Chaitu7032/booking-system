from django.shortcuts import render, redirect
from .models import Booking
from datetime import date

def booking_view(request):
    today = date.today()

    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        reservation_date = request.POST.get('reservation_date')
        reservation_slot = request.POST.get('reservation_slot')

        # Save booking
        Booking.objects.create(
            first_name=first_name,
            reservation_date=reservation_date,
            reservation_slot=reservation_slot
        )

        # Get bookings for that date
        bookings = Booking.objects.filter(reservation_date=reservation_date)
        return render(request, 'booking_form.html', {
            'message': '✅ Your booking has been confirmed!',
            'today': reservation_date,
            'bookings': bookings
        })

    bookings = Booking.objects.filter(reservation_date=today)
    return render(request, 'booking_form.html', {
        'today': today,
        'bookings': bookings
    })
